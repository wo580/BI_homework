#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Date    : 2020-08-26 20:24:13
# @Author  : Muxiaoxiong
# @email   : xiongweinie@foxmail.com

from efficient_apriori import apriori
trade_list=[]
with open("Market_Basket_Optimisation.csv") as ff:
	for line in ff:
		line=line.strip()
		trade=line.split(',')
		trade_list.append(trade)
#使用Apriori算法
itemsets, rules = apriori(trade_list, min_support=0.05,  min_confidence=0.3)
print("频繁项集：", itemsets)
print("关联规则：", rules)
