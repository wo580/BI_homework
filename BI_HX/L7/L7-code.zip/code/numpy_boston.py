# 使用numpy实现Boston房价预测
import numpy as np
from sklearn.datasets import load_boston
from sklearn.utils import shuffle, resample

# 数据加载
data = load_boston()
X_ = data['data']
y = data['target']
#print(X_)
#print(len(X_)) # 506
y = y.reshape(y.shape[0],1)

# 数据规范化
X_ = (X_ - np.mean(X_, axis=0)) / np.std(X_, axis=0)
#print(X_)

np.random.seed(33)

n_features = X_.shape[1]
n_hidden = 16
w1 = np.random.randn(n_features, n_hidden)
b1 = np.zeros(n_hidden)
w2 = np.random.randn(n_hidden, 1)
b2 = np.zeros(1)

# relu函数
def Relu(x):
    result = np.where(x<0,0,x)
    return result

# 设置学习率
learning_rate = 1e-5

def MSE_loss(y, y_hat):
    return np.mean(np.square(y_hat - y))

def Linear(X, W1, b1):
    result = X.dot(W1) + b1
    return result

# 5000次迭代
for t in range(5000):
    # 前向传播，计算预测值y
    l1 = Linear(X_, w1, b1)
    s1 = Relu(l1)
    #s1 = np.maximum(l1, 0)
    #print('s1=', s1.shape) #(506, 10)
    #print('w2=', w2.shape) #(506, 10)
    #print('s1.T=', s1.T.shape) #(10, 506)
    y_pred = Linear(s1, w2, b2)
    #y_pred = l2 = s1.dot(w2) + b2
    #print('y_pred=', y_pred.shape) #(506, 1)
    #print('y=', y.shape) #(506, 1)


    #temp = X.dot(w1)
    #temp_relu = np.maximum(temp, 0)
    #y_pred = temp_relu.dot(w2)

    # 计算损失函数
    loss = MSE_loss(y, y_pred)
    #print(y_pred)
    #print(y_pred.shape)
    print(t, loss)

    # 反向传播，基于loss 计算w1和w2的梯度
    grad_y_pred = 2.0 * (y_pred - y)
    grad_w2 = s1.T.dot(grad_y_pred) #(10, 506) * (506, 506)
    #print('grad_w2=', grad_w2.shape) #(10, 506)
    #print('grad_y_pred=', grad_y_pred.shape) #(506, 506)
    #print('w2.T=', w2.T.shape) #(1, 10)
    grad_temp_relu = grad_y_pred.dot(w2.T) #(506, 506),  (1, 10)
    #grad_temp = grad_temp_relu.copy()
    grad_temp_relu[l1<0] = 0
    grad_w1 = X_.T.dot(grad_temp_relu)

    # 更新权重
    w1 -= learning_rate * grad_w1
    w2 -= learning_rate * grad_w2
print('w1={} \n w2={}'.format(w1, w2))
#print(w1) 
#print(w2) 
