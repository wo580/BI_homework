import time

timestamp = time.time()
print("当前时间戳为:", timestamp)
localtime = time.localtime(timestamp)
print("本地时间为 :", localtime)

from datetime import datetime
str1 = '2020-04-10'
result = datetime.strptime(str1, '%Y-%m-%d')
print(result)
result = datetime.strptime(str1, '%Y-%d-%m')
print(result)

from datetime import timedelta
# 从2014-11-18遍历到2014-12-18
str1 = '2014-11-18'
temp_date = datetime.strptime(str1, '%Y-%m-%d')
delta = timedelta(days=1)
for i in range(30):
	temp_date  = temp_date + delta
	print(temp_date)