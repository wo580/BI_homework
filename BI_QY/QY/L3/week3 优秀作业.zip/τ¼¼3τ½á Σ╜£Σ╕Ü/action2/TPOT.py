import numpy as np
import pandas as pd
#from sklearn.tree import DecisionTreeClassifier
from tpot import TPOTClassifier
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import cross_val_score
from sklearn import metrics
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import train_test_split


# 数据加载
train_data = pd.read_csv('./train.csv')

# 数据探索
# 查看train_data信息
#pd.set_option('display.max_columns', None) #显示所有列
print('查看数据信息：列名、非空个数、类型等')
print(train_data.info())
print('-'*30)
print('查看数据摘要')
print(train_data.describe())
print('-'*30)
print('查看离散数据分布')
print(train_data.describe(include=['O']))
print('-'*30)
print('查看前5条数据')
print(train_data.head())
print('-'*30)
print('查看后5条数据')
print(train_data.tail())

# 使用平均年龄来填充年龄中的nan值
train_data['Age'].fillna(train_data['Age'].mean(), inplace=True)

# 使用票价的均值填充票价中的nan值
train_data['Fare'].fillna(train_data['Fare'].mean(), inplace=True)

print(train_data['Embarked'].value_counts())
# 使用登录最多的港口来填充登录港口的nan值
train_data['Embarked'].fillna('S', inplace=True)

# 特征选择
features = ['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']
train_features = train_data[features]
train_labels = train_data['Survived']

#test_labels = test_data['Survived']
print('特征值')
print(train_features)



dvec=DictVectorizer(sparse=False)
train_features=dvec.fit_transform(train_features.to_dict(orient='record'))
print(dvec.feature_names_)

X_train,X_test,Y_train,Y_test = train_test_split(train_features,train_labels,train_size=0.8, test_size=0.2)

# TPOT分类器
tpot = TPOTClassifier(generations=7,population_size=30,verbosity=2)

#tpot训练选择模型
tpot.fit(X_train,Y_train)

print(u'score为 %.4lf' %tpot.score(X_test,Y_test))
tpot.export('tpot_titanic_pipeline.py')
